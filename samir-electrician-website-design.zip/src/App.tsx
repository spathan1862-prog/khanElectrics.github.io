import React, { useState } from 'react';
import { Menu, X, Phone, Mail, MapPin, Star, Zap, Lightbulb, CheckCircle, Clock, Shield, Award, Facebook, Instagram, Twitter, ArrowRight } from 'lucide-react';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const services = [
    {
      icon: <Lightbulb className="w-12 h-12" />,
      title: 'Light Fitting',
      description: 'Professional installation of all types of indoor and outdoor lighting fixtures for residential and commercial properties.'
    },
    {
      icon: <Zap className="w-12 h-12" />,
      title: 'Underground Light Fitting',
      description: 'Specialized underground lighting installation for gardens, pathways, driveways, and landscape illumination.'
    },
    {
      icon: <Star className="w-12 h-12" />,
      title: 'Room Decorations',
      description: 'Beautiful decorative lighting solutions to transform your spaces with ambient, accent, and task lighting.'
    }
  ];

  const testimonials = [
    {
      name: 'Rajesh Sharma',
      text: 'Excellent work! Samir installed beautiful lighting in our new home. Very professional and clean work.',
      rating: 5
    },
    {
      name: 'Priya Patel',
      text: 'The underground lighting for our garden looks amazing. Samir is very skilled and reliable. Highly recommended!',
      rating: 5
    },
    {
      name: 'Amit Kumar',
      text: 'Transformed our living room with beautiful decorative lighting. Great attention to detail and fair prices.',
      rating: 5
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-gray-900 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="bg-amber-500 p-2 rounded-full">
                <Zap className="w-8 h-8 text-gray-900" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Samir Khan</h1>
                <p className="text-xs text-amber-400">Professional Electrician</p>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#home" className="hover:text-amber-400 transition">Home</a>
              <a href="#services" className="hover:text-amber-400 transition">Services</a>
              <a href="#about" className="hover:text-amber-400 transition">About</a>
              <a href="#testimonials" className="hover:text-amber-400 transition">Testimonials</a>
              <a href="#contact" className="bg-amber-500 text-gray-900 px-6 py-2 rounded-full font-semibold hover:bg-amber-400 transition">Contact Me</a>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pb-4 space-y-4">
              <a href="#home" className="block hover:text-amber-400 transition" onClick={() => setIsMenuOpen(false)}>Home</a>
              <a href="#services" className="block hover:text-amber-400 transition" onClick={() => setIsMenuOpen(false)}>Services</a>
              <a href="#about" className="block hover:text-amber-400 transition" onClick={() => setIsMenuOpen(false)}>About</a>
              <a href="#testimonials" className="block hover:text-amber-400 transition" onClick={() => setIsMenuOpen(false)}>Testimonials</a>
              <a href="#contact" className="block bg-amber-500 text-gray-900 px-6 py-2 rounded-full font-semibold text-center" onClick={() => setIsMenuOpen(false)}>Contact Me</a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-32 h-32 bg-amber-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-48 h-48 bg-amber-400 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block bg-amber-500 text-gray-900 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                ⚡ Available 24/7 for Emergency Services
              </div>
              <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                Brighten Your World with 
                <span className="text-amber-400"> Professional Lighting</span>
              </h2>
              <p className="text-xl text-gray-300 mb-8">
                Hi, I'm Samir Khan - your trusted electrician specializing in light fitting, underground lighting, and beautiful room decorations. Let me illuminate your space!
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="#contact" className="bg-amber-500 text-gray-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-amber-400 transition flex items-center justify-center space-x-2">
                  <Phone className="w-5 h-5" />
                  <span>Get Free Quote</span>
                </a>
                <a href="#services" className="border-2 border-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-gray-900 transition flex items-center justify-center space-x-2">
                  <span>View Services</span>
                  <ArrowRight className="w-5 h-5" />
                </a>
              </div>
            </div>
            <div className="hidden md:flex justify-center">
              <div className="relative">
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 p-1 rounded-full">
                  <div className="bg-gray-800 p-8 rounded-full">
                    <Lightbulb className="w-48 h-48 text-amber-400 animate-pulse" />
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 bg-green-500 text-white px-4 py-2 rounded-full font-bold flex items-center space-x-1">
                  <span className="w-3 h-3 bg-white rounded-full animate-pulse"></span>
                  <span>Available Now</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-amber-600 font-semibold text-lg mb-2">WHAT I OFFER</h3>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">My Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Professional electrical services tailored to meet your lighting needs with quality and precision.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-2xl hover:shadow-2xl transition-all duration-300 group border border-gray-100">
                <div className="text-amber-500 mb-6 group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
                <ul className="mt-6 space-y-2">
                  {['Residential', 'Commercial', 'Industrial'].map((item, i) => (
                    <li key={i} className="flex items-center text-gray-700">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gradient-to-br from-gray-100 to-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="bg-gradient-to-br from-amber-400 to-amber-600 p-2 rounded-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?auto=format&fit=crop&q=80&w=600&h=450" 
                  alt="Electrician working" 
                  className="rounded-xl w-full h-80 object-cover"
                />
              </div>
            </div>
            <div>
              <h3 className="text-amber-600 font-semibold text-lg mb-2">ABOUT ME</h3>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Samir Khan</h2>
              <p className="text-xl text-gray-700 mb-6 leading-relaxed">
                With over 10 years of experience in electrical services, I specialize in creating beautiful, safe, and efficient lighting solutions for homes and businesses.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                My commitment to quality workmanship, safety, and customer satisfaction has made me the go-to electrician for countless satisfied clients. No job is too big or too small - I handle every project with the same level of dedication and expertise.
              </p>
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="text-center bg-white p-4 rounded-xl shadow-md">
                  <div className="text-3xl font-bold text-amber-600">10+</div>
                  <div className="text-gray-600 text-sm">Years Experience</div>
                </div>
                <div className="text-center bg-white p-4 rounded-xl shadow-md">
                  <div className="text-3xl font-bold text-amber-600">1000+</div>
                  <div className="text-gray-600 text-sm">Happy Clients</div>
                </div>
                <div className="text-center bg-white p-4 rounded-xl shadow-md">
                  <div className="text-3xl font-bold text-amber-600">100%</div>
                  <div className="text-gray-600 text-sm">Satisfaction</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center space-x-2 bg-amber-100 text-amber-800 px-4 py-2 rounded-full">
                  <Shield className="w-5 h-5" />
                  <span className="font-semibold">Licensed & Insured</span>
                </div>
                <div className="flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full">
                  <Award className="w-5 h-5" />
                  <span className="font-semibold">Certified Electrician</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-amber-400 font-semibold text-lg mb-2">WHY CHOOSE ME</h3>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Why Choose Samir Khan?</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Experience the difference of professional, reliable, and affordable electrical services.
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="bg-amber-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="w-10 h-10 text-gray-900" />
              </div>
              <h3 className="text-xl font-bold mb-2">24/7 Availability</h3>
              <p className="text-gray-400">Always available for emergency electrical services</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-amber-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-10 h-10 text-gray-900" />
              </div>
              <h3 className="text-xl font-bold mb-2">Safety First</h3>
              <p className="text-gray-400">All work follows strict safety standards and regulations</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-amber-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="w-10 h-10 text-gray-900" />
              </div>
              <h3 className="text-xl font-bold mb-2">Quality Work</h3>
              <p className="text-gray-400">Premium materials and meticulous attention to detail</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-amber-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Zap className="w-10 h-10 text-gray-900" />
              </div>
              <h3 className="text-xl font-bold mb-2">Fast Response</h3>
              <p className="text-gray-400">Quick response time for all service calls</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-amber-600 font-semibold text-lg mb-2">TESTIMONIALS</h3>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">What Clients Say</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Don't just take my word for it - hear from some of my satisfied customers.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-2xl border border-gray-100 hover:shadow-xl transition">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.text}"</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-amber-600 text-sm">Verified Customer</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-br from-gray-100 to-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-amber-600 font-semibold text-lg mb-2">GET IN TOUCH</h3>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Contact Me</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Ready to brighten up your space? Get in touch for a free consultation and quote.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <div className="bg-white p-8 rounded-2xl shadow-lg mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Contact Information</h3>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="bg-amber-100 p-3 rounded-full">
                      <Phone className="w-6 h-6 text-amber-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Phone</h4>
                      <p className="text-gray-600 text-lg">+91 98765 43210</p>
                      <p className="text-sm text-gray-500">Available 24/7</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="bg-amber-100 p-3 rounded-full">
                      <Mail className="w-6 h-6 text-amber-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Email</h4>
                      <p className="text-gray-600 text-lg">samir.electrician@gmail.com</p>
                      <p className="text-sm text-gray-500">Response within 24 hours</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <div className="bg-amber-100 p-3 rounded-full">
                      <MapPin className="w-6 h-6 text-amber-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Location</h4>
                      <p className="text-gray-600 text-lg">Mumbai, Maharashtra</p>
                      <p className="text-sm text-gray-500">Serving all surrounding areas</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-900 text-white p-8 rounded-2xl">
                <h3 className="text-xl font-bold mb-4">Follow Me</h3>
                <div className="flex space-x-4">
                  <a href="#" className="bg-gray-800 p-4 rounded-full hover:bg-amber-500 hover:text-gray-900 transition">
                    <Facebook className="w-6 h-6" />
                  </a>
                  <a href="#" className="bg-gray-800 p-4 rounded-full hover:bg-amber-500 hover:text-gray-900 transition">
                    <Instagram className="w-6 h-6" />
                  </a>
                  <a href="#" className="bg-gray-800 p-4 rounded-full hover:bg-amber-500 hover:text-gray-900 transition">
                    <Twitter className="w-6 h-6" />
                  </a>
                </div>
              </div>
            </div>
            <div>
              <form onSubmit={handleSubmit} className="bg-white p-8 rounded-2xl shadow-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Send a Message</h3>
                {isSubmitted ? (
                  <div className="bg-green-100 text-green-800 p-6 rounded-xl text-center">
                    <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                    <h4 className="text-xl font-bold mb-2">Thank You!</h4>
                    <p>Your message has been sent successfully. I'll get back to you soon!</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Your Name</label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition"
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Email Address</label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition"
                        placeholder="Enter your email"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Phone Number</label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition"
                        placeholder="Enter your phone number"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Your Message</label>
                      <textarea
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        rows={4}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition resize-none"
                        placeholder="Describe your electrical needs..."
                        required
                      ></textarea>
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-amber-500 text-gray-900 py-4 rounded-xl font-bold text-lg hover:bg-amber-400 transition flex items-center justify-center space-x-2"
                    >
                      <span>Send Message</span>
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-6 md:mb-0">
              <div className="bg-amber-500 p-2 rounded-full">
                <Zap className="w-8 h-8 text-gray-900" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Samir Khan</h1>
                <p className="text-amber-400 text-sm">Professional Electrician</p>
              </div>
            </div>
            <div className="text-center md:text-right">
              <p className="text-gray-400 mb-2">© 2024 Samir Khan. All rights reserved.</p>
              <p className="text-gray-500 text-sm">Licensed & Insured Electrical Services</p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
            <p>Serving Mumbai & surrounding areas with quality electrical solutions</p>
          </div>
        </div>
      </footer>
    </div>
  );
}